pygameで作成した簡単なゴルフゲームです。

「golf_game/dist」に実行ファイル（golfgame.exe）が入っているので、ダブルクリックで実行してください。