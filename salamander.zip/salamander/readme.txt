DECO*27 - サラマンダー feat. 初音ミク(https://youtu.be/-H2PCK7DJsQ?si=l_DO2ZSno_u9TyY4)のMusicVideoの世界の中で、初音ミクのVRMモデルが踊るところを見ることができるUnityアプリケーションです。
salamander_mikuを実行してください。
アプリケーションを終了するにはSpaceキーを押してください。

Credits(敬称略)
音楽 & 動画素材：DECO*27 / 「Otoiro(https://otoiro.co.jp/special/)」
VRMモデル：gasl / 「初音ミク/ VRM 0.x ver2.43(https://hub.vroid.com/characters/8356926682122020177/models/8060687616841148173)」
Motion：ソーマ / 「【MMD】サラマンダー【モーション配布】(https://www.nicovideo.jp/watch/sm40546090)

この作品はピアプロ・キャラクター・ライセンスに基づいてクリプトン・フューチャー・メディア株式会社のキャラクター「初音ミク」を描いたものです。
この作品を非営利かつ私的利用以外の目的で用いることを固く禁じます。