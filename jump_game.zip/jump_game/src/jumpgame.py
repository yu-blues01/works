# JUMP GAME
import pyxel
import random

def abs(num):
    if num < 0:
        return -num
    else:
        return num


# 衝突時のプレイヤーの移動量を算出
def backward(num):
    if num < 0:
        return(16-abs(num))
    else:
        return(16-abs(num))

class Object: # コインとレンガ用のクラス
    def __init__(self, x, y, chrtype):
        self.x = x
        self.y = y
        self.chrtype = chrtype

class App:
    def __init__(self):
        pyxel.init(160, 120)
        # リソースファイルを読み込む
        pyxel.load(r"./assets/my_resource.pyxres")
        # タイトル画面フラグをオン
        self.titlemode = True
        pyxel.run(self.update, self.draw)

    def update(self):
        if self.titlemode == True:
            if pyxel.btn(pyxel.KEY_SPACE) == True:
                self.px = 80 # プレイヤーX座標
                self.py = 60 # プレイヤーY座標
                self.py1 = 0 # 落下速度
                self.time = 0
                # 地面フラグをオフ
                self.ground = False
                self.score = 0
                self.speed = 1
                # ゲームオーバーカウンタを0
                self.gameover = 0
                # タイトル画面フラグをオフ
                self.titlemode = False
                # コインとレンガを格納するリスト
                self.objects = []
                for i in range(10):
                    obj = Object(i*16, 112, 1)
                    # レンガを画面に追加（最初の床）
                    self.objects.append(obj)
            return

        # ゲームオーバー時の処理
        if self.gameover > 0:
            self.gameover = self.gameover + 1
            if self.gameover > 3 * 30:
                self.titlemode = True
            return

        # プレイヤーの右移動
        if pyxel.btn(pyxel.KEY_RIGHT) == True:
            self.px = self.px + 2

        # プレイヤーの左移動
        if pyxel.btn(pyxel.KEY_LEFT) == True:
            self.px = self.px - 2

        # プレイヤーは地面にいるか？
        if self.ground == True:
            # プレイヤーのジャンプ
            if pyxel.btn(pyxel.KEY_SPACE) == True:
                self.py1 = -5 # ジャンプ開始
                self.ground = False

        else:
            # 落下速度を変更
            self.py1 = self.py1 + 0.2
            if self.py1 > 5:
                self.py1 = 5
            # プレイヤーの落下
            self.py = self.py + self.py1

        # 画面外に出たらゲームオーバー
        if self.px < 0 or self.py > 120:
            self.gameover = 1

        self.ground = False

        # コインとレンガの処理
        for obj in self.objects:
            # 左に移動
            obj.x = obj.x - self.speed
            dx = self.px - obj.x
            dy = self.py - obj.y
            # プレイヤーとの衝突判定
            if abs(dx) < 16 and abs(dy) < 16:
                # コインと衝突した場合
                if obj.chrtype == 0:
                    # スコアを加算
                    self.score = self.score + 1
                    # 効果音を鳴らす
                    pyxel.play(0, 0, loop=False)
                    obj.x = -999 # コインを画面から消去
                else: # レンガと衝突した場合
                    if abs(dx) < abs(dy):
                        # プレイヤーのY座標を修正
                        self.py = self.py - backward(dy)
                        self.py1 = 0
                        # 地面フラグをオン
                        if dy < 0:
                            self.ground = True
                    else:
                        # プレイヤーのX座標を修正
                        self.px = self.px - backward(dx)

        for obj in self.objects:
            if obj.x < -16:
                # 画面外のレンガまたはコインを消去する
                self.objects.remove(obj)

        # プレイ時間計測用の変数
        self.time = self.time + 1
        if self.time % 16 == 8:
            obj = Object(168, random.randrange(3) * 16 + 80, 1)
            # レンガを画面に追加
            self.objects.append(obj)

        if self.time % 32 == 8:
            obj = Object(168, random.randrange(3) * 16 + 16, 0)
            # コインを画面に追加
            self.objects.append(obj)

        if self.time % 300 == 0:
            # スクロールの速度を上げる
            self.speed = self.speed + 0.5

    def draw(self):
        if self.titlemode == True:
            pyxel.cls(0)
            pyxel.text(50, 50, "  JUMP GAME  ", 7)
            pyxel.text(50, 100, "PUSH SPACE KEY", 7)
        else:
            pyxel.cls(12)
            u = 16 * (int(self.time / 5) % 2)
            v = 0
            # プレイヤーを表示
            pyxel.blt(self.px-8, self.py-8, 0, u, v, 16, 16, 0)
            for obj in self.objects:
                u = obj.chrtype * 16
                v = 16
                # コインとレンガを表示
                pyxel.blt(obj.x-8, obj.y-8, 0, u, v, 16, 16, 0)

            pyxel.text(60, 2, "SCORE:"+str(self.score), 1)
            if self.gameover > 0:
                pyxel.text(60, 50, "GAME OVER", 1)
App()
