オリジナルのVRMモデルが踊るところを見ることができるUnityアプリケーションです。
CRS_originalを実行してください。
アプリケーションを終了するにはSpaceキーを押してください。


この作品はユニティちゃんライセンス条項(https://unity-chan.com/contents/license_jp/, © Unity Technologies Japan/UCL)の元に提供されています。
ライセンス条項に基づき、ライセンス関連ファイル一式(UCL2.02.zip)を同梱しています。
VRMモデルはVRoid(https://vroid.pixiv.help/hc/ja/articles/4402394424089-AvatarSample-A-B-C)が公開しているAvatarSample-Bを使用しました。